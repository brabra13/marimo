"""Temporary package for development."""

__version__ = "0.0.12"

import numpy as np
def dummy_function(name: str):
    """Dummy function to ensure package has content."""
    return f"Hello, {name}!"
